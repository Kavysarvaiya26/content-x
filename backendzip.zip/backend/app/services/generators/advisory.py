from app.schemas import Advisory
from app.services.generators.base import BaseGenerator


class AdvisoryGenerator(BaseGenerator):
    output_type = "advisory"
    schema = Advisory

    def to_markdown(self, payload: Advisory) -> str:
        recs = "\n".join(f"1. {x}" for x in payload.recommendations)
        watch = "\n".join(f"- {x}" for x in payload.watch_items)
        caveats = "\n".join(f"- {x}" for x in payload.caveats)
        return (
            f"# {payload.header}\n\n"
            f"## Situation\n{payload.situation}\n\n"
            f"## Operational Assessment\n{payload.assessment}\n\n"
            f"## Recommended Actions\n{recs}\n\n"
            f"## Watch Items & Monitoring\n{watch}\n\n"
            f"## Caveats & Operational Constraints\n{caveats}\n"
        )
